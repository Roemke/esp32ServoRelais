#define mySSID "FamilyWlan"
#define myPASSWORD "tiWPAk@FamWlan42"

//eigener ap
#define apSSID "ESP32ServoWlan"
#define apPASSWORD "tiwpak@tardis42"

//der broker, hmm noch im einsatz? ich denke
#define mqttBROKER "192.168.0.203"
#define mqttPORT 1883


//der server fuer den Zugriff auf den Inverter über modbus
#define inverterServerGet "http://192.168.0.203:8090/data"

