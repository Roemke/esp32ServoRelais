#ifndef POWER_H
#define POWER_H
#include "config.h"
#include <ModbusIP_ESP8266.h>
#include <HTTPClient.h>
#include "credentials.h"

#include <ArduinoJson.h> //ArduinoJson hat ein anderes Speicherkonzept als Arduino_Json


//power direkt abfragen nicht über mqtt (ist so einfach schneller)
#define powerHouseGet        "http://192.168.0.238/cm?cmnd=status%2010"
#define powerBlueInverterGet "http://192.168.0.237/cm?cmnd=status%2010"
#define powerDeyeInverterGet "http://192.168.0.239/cm?cmnd=status%2010"

//Die Leistungswerte

class Power {
   public:
    int house;           //aus webapi (vom esp am Stromzaehler)
    int blueInverter;    //aus webapi (von Tasmota Steckdose)
    int deyeInverter;    //aus webapi  ""
    
    //daten des Wechselrichters von solarEdge, hmm hier bin ich noch dran
    float seHouse; 
    float seBattery;   
    float seGrid; //ins Stromnetz  ac
    float seSun; //von den solarzellen, ac  

    


    int bluettiOutDC;         //aus bluetooth ab hier
    int bluettiOutAC;
    int bluettiIn;
    int bluettiPercent; 
    int maxPowerBlue;
    int minPercentBlue;
    bool bluettiDCState; 

    
    //Mittelwerte
    /* das ist noch nicht durchdacht, weiss nicht, ob ich das möchte  
    int mHouse;           
    int mBlueInverter; 
    int mDeyeInverter;    
    int mBluetti;         
    int mBluettiPercent;  
    */

    //Fehler 
    bool eHouse;
    bool eBlueInverter;
    bool eDeyeInverter;
    bool eBluetti;  //bluetooth

    //zaehler fuer die Mittelwerte
    /*
    int blueCounter; 
    int apiCounter; 
    */
    //Methoden 
    public:
      Power()
      {
        eHouse = eBlueInverter = eDeyeInverter = eBluetti = true;
        bluettiDCState = false; 
        house = blueInverter = deyeInverter = bluettiOutDC = bluettiOutAC = bluettiIn = bluettiPercent = 0;
        maxPowerBlue = 100;
        minPercentBlue = 20;
        seHouse = seGrid = seSun = seBattery = 0; 
        http.useHTTP10(true); //use old http1.0 - stream is not chunked
      }
      void actualizeData();
      void beginModBus();

      //char *getJSON(const char *action);
      size_t getJSON(const char *action, char *buf, size_t buflen);
      char *getString();

    private:
      HTTPClient http; 
      //Verwendung von modbus tcp, um den SolarEdge Inverter abzufragen
      ModbusIP mb;                   // Modbus-Objekt als Mitglied
      IPAddress inverterIP = IPAddress(192, 168, 0, 205); // Fest zugewiesene IP
      uint16_t port = 1502;             // Port, normal 502
      uint16_t slaveID = 1;            // Modbus-ID    - egal?

      //standard-Tasmotasteckdose
      void readTasmotaSteckdose(const char *getString, int &power, bool &err);
      
      void readFromInverter();
           
};
#endif
